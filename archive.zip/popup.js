document.getElementById("startDay").addEventListener("click", () => {
    chrome.storage.local.set({ dayStarted: new Date().toLocaleString() }, () => {
        alert("آج کا کام شروع ہوگیا!");
    });
});

document.getElementById("endDay").addEventListener("click", () => {
    chrome.storage.local.set({ dayEnded: new Date().toLocaleString() }, () => {
        alert("آج کا کام ختم ہوگیا!");
    });
});

document.getElementById("saveRate").addEventListener("click", () => {
    const itemName = document.getElementById("itemName").value;
    const itemRate = document.getElementById("itemRate").value;

    if (!itemName || !itemRate) {
        alert("نام اور ریٹ دونوں لکھیں!");
        return;
    }

    chrome.storage.local.get(["rates"], (data) => {
        const allRates = data.rates || {};

        allRates[itemName] = itemRate;

        chrome.storage.local.set({ rates: allRates }, () => {
            alert("ریٹ محفوظ ہوگیا!");
        });
    });
});