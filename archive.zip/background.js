chrome.runtime.onInstalled.addListener(() => {
  console.log("App Installed");
});

chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.sendMessage(tab.id, { action: "open_app" });
});